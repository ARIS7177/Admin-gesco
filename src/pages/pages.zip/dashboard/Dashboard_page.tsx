import MainSection from "../../components/Main/Main";

export default function DashboardPage() {
  return (
    <>
      <MainSection pageTitle="Tableau de Bord">

      </MainSection>
    </>
  )
}