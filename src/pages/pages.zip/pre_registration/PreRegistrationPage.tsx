import MainSection from "../../components/Main/Main";

export default function PreRegistrationPage() {
  return (
    <>
      <MainSection pageTitle="Préinscriptions">

      </MainSection>
    </>
  )
}