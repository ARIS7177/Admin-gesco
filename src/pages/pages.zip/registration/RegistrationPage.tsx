import MainSection from "../../components/Main/Main";

export default function RegistrationPage() {
  return (
    <>
      <MainSection pageTitle="Inscriptions">

      </MainSection>
    </>
  )
}