import MainSection from "../../components/Main/Main";

export default function UsersPage() {
  return (
    <>
      <MainSection pageTitle="Utilisateurs">

      </MainSection>
    </>
  )
}